雀卓スコア Androidプロジェクト（APK作成用）

重要：このZIPはAndroid StudioでAPKをビルドするためのプロジェクトです。APKそのものではありません。
この実行環境にはAndroid SDK/Gradleがないため、APKをここで直接コンパイルできません。

APKの作り方
1. PCにAndroid Studioをインストール
2. Android Studioで「Open」を選び、このZIPを展開した JantakuScore フォルダを開く
3. SDKやGradleのインストール/同期を促されたら許可する
4. メニュー Build > Build Bundle(s) / APK(s) > Build APK(s)
5. 完了通知の「locate」から app-debug.apk を取得し、Android端末に移す
6. Android側で許可を求められたら「不明なアプリのインストール」を許可してAPKをインストール

このアプリについて
- 点数管理、親決め、戦績、画像選択画面を含むWebアプリをAndroid WebViewで表示します。
- 対局記録は端末内のWebViewストレージに保存されます。
- 画像認識AIは別途APIサーバーが必要です。OpenAI APIキーをAPKに埋め込まないでください。
- APIをHTTPSで公開したあと、app/src/main/assets/index.html 内の API_BASE_URL をそのURLに変更してからビルドしてください。
  例: const API_BASE_URL = "https://your-domain.example";
- APIサーバーがない場合、画像認識は動きません。点数管理などのローカル機能は利用できます。

注意
- このプロジェクトは試作版です。Android Studioでのビルド・実機動作確認はまだ行っていません。
- 麻雀の点数計算は簡易版です。公式な点数計算機として使用する前に検証してください。
